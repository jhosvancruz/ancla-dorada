<!doctype html>
<html>
    <head>
      <meta charset="utf-8">
      <title>Insertar Usuarios</title>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript" src="js/code.js"></script>
    </head>
    <body>
        <div>
            <h1>Insertar Usuarios</h1>
            <label>Usuario:</label>
            <input type="text" id="usuario"><br>
            <label>Contraseña:</label>
            <input type="password" id="pass"><br>
            <input type="button" value="Registrar" id="btnRegistrar">
        </div>
        <div id="resultado"></div>
    </body>
</html>
