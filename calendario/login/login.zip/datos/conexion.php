<?php
class conexion
{
  function conectar(){
    return mysqli_connect("localhost","alebrij3","Jhosvan2018");
  }
}
 ?>
